# chat_w_pdf_openai
This is to create a streamlit based chatbot app to chat with local pdf files.
The app can search answers in the provided pdf, is no relavant content is found, will try to answer from its own knowledge.
